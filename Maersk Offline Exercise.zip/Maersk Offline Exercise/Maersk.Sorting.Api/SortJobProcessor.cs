﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Maersk.Sorting.Api
{
    public class SortJobProcessor : ISortJobProcessor
    {
        private readonly ILogger<SortJobProcessor> _logger;
        private readonly List<SortJob> sortJobs;

        public SortJobProcessor(ILogger<SortJobProcessor> logger)
        {
            _logger = logger;
            sortJobs = new List<SortJob>();
        }
        int i = 0;
        public SortJob Enqueue(SortJob pendingJob)
        {
            var task = Task.Run(() => (
            sortJobs[i] = Process(pendingJob)
            )
            );
            if (task.IsCompleted)
            {
                sortJobs.Add(task.Result);
            }
            else
            {
                sortJobs.Add(pendingJob);
            }
            return sortJobs[i];
        }

        public SortJob GetSortJob(Guid jobId)
        {
            return sortJobs.First(x => x.Id == jobId);
        }

        public SortJob[] GetSortJobs()
        {
            return sortJobs.ToArray<SortJob>();
        }

        public SortJob Process(SortJob job)
        {
            _logger.LogInformation("Processing job with ID '{JobId}'.", job.Id);

            var stopwatch = Stopwatch.StartNew();

            var output = job.Input.OrderBy(n => n).ToArray();      

            var duration = stopwatch.Elapsed;

            _logger.LogInformation("Completed processing job with ID '{JobId}'. Duration: '{Duration}'.", job.Id, duration);
            i++;
            return new SortJob(
                id: job.Id,
                status: SortJobStatus.Completed,
                duration: duration,
                input: job.Input,
                output: output);
        }
    }
}
