﻿using Microsoft.AspNetCore.Mvc;
using System;

namespace Maersk.Sorting.Api.Controllers
{
    [ApiController]
    [Route("sort")]
    public class SortController : ControllerBase
    {
        private readonly ISortJobProcessor _sortJobProcessor;

        public SortController(ISortJobProcessor sortJobProcessor)
        {
            _sortJobProcessor = sortJobProcessor;
        }


        [HttpPost]
        public ActionResult<SortJob> EnqueueJob(int[] values)
        {
            var pendingJob = new SortJob(
               id: Guid.NewGuid(),
               status: SortJobStatus.Pending,
               duration: null,
               input: values,
               output: null);
            var result = _sortJobProcessor.Enqueue(pendingJob);

            return Ok(result);
        }

        [HttpGet]
        public ActionResult<SortJob[]> GetJobs()
        {
            var result = _sortJobProcessor.GetSortJobs();
            return Ok(result);
        }

        [HttpGet("{jobId}")]
        public ActionResult<SortJob> GetJob(Guid jobId)
        {
            var result = _sortJobProcessor.GetSortJob(jobId);
            return Ok(result);
        }
    }
}
