﻿using System;
using System.Threading.Tasks;

namespace Maersk.Sorting.Api
{
    public interface ISortJobProcessor
    {
        SortJob Process(SortJob job);
        SortJob[] GetSortJobs();
        SortJob GetSortJob(Guid jobId);
        SortJob Enqueue(SortJob pendingJob);
    }
}